class TipoDeEvento:
    def __init__(self, nombre):
        self.nombre = nombre

    def getNombre(self):
        return self.nombre

    # Por eliminar. Tenemos t0do en strings en el login. No hace falta esto.
