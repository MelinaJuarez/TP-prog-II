ciudadanos_usuarios = []
ciudadanos_usuarios_nombres = []
ciudadanos_usuarios_claves = []
ciudadanos_usuarios_celulares = []
ciudadanos_usuarios_CUILs = []

ciudadanos_bloqueados_usuarios = []
ciudadanos_a_bloquear = []
administradores_usuarios = []
ad_nombres = ["Admin"]
ad_claves = [000]

eventos = []
Tipos_de_eventos = []

sensores = []
